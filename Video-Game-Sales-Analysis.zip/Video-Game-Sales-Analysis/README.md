# Video Game Sales Analysis – Power BI Dashboard

A Power BI dashboard that compares video game sales across **Europe, Japan and North America**, by game, by genre and by release year.

**Author:** Sampath Peramalasetty

## What the dashboard shows

| Visual | Question it answers |
|---|---|
| Europe, Japan and North America sales by game | Which individual games sold the most in each region? |
| Games by genre (donut) | How is the catalogue split across genres? |
| Sales by genre with average rank | Which genres sell the most, and how do they rank? |
| Rank per year (gauge) and year filter | How do ranks vary by release year? |

## Fields used

`Name`, `Rank`, `Genre`, `Year`, `EU_Sales`, `JP_Sales`, `NA_Sales`

## Tools

- Microsoft Power BI Desktop
- Data cleaning and preparation in Excel and Python

## Repository structure

```text
Video-Game-Sales-Analysis/
├── PowerBI/
│   └── Video_Game_Sales.pbix
├── Screenshots/
│   └── dashboard.png
└── README.md
```

## How to open it

1. Download `PowerBI/Video_Game_Sales.pbix`.
2. Open it in Power BI Desktop (free for Windows).

## Preview

![Dashboard](Screenshots/dashboard.png)

## Notes

Add the source of the dataset here (for example, the website you downloaded it from) and what you cleaned or changed before loading it.
